#ifndef ITEM_H
#define ITEM_H

struct Item {
    int value;
};

#endif
